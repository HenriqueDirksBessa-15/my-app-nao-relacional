const { ClickHouse } = require('clickhouse');

const clickhouse = new ClickHouse({
  url: process.env.CLICKHOUSE_URL || 'http://localhost',
  port: Number(process.env.CLICKHOUSE_PORT || 8123),
  debug: false,
  basicAuth: {
    username: process.env.CLICKHOUSE_USER || 'default',
    password: process.env.CLICKHOUSE_PASSWORD || '',
  },
  config: {
    database: process.env.CLICKHOUSE_DB || 'default',
  },
  format: 'json',
});

async function ensureTable() {
  try {
    await clickhouse.query(`
      CREATE TABLE IF NOT EXISTS temperaturas_diarias
      (
        timestamp DateTime,
        maquina String,
        valor Float32
      )
      ENGINE = MergeTree()
      ORDER BY (timestamp, maquina)
    `).toPromise();
  } catch (err) {
    console.error('Falha ao garantir tabela temperaturas_diarias no ClickHouse:', err.message);
  }
}

async function insertTemperaturas(rows) {
  if (!rows.length) return;

  await clickhouse
    .insert(
      'INSERT INTO temperaturas_diarias (timestamp, maquina, valor) VALUES',
      rows
    )
    .toPromise();
}

ensureTable();

module.exports = { clickhouse, insertTemperaturas };
