const express = require('express');
const router = express.Router();
const influx = require('../db/influx');
const { insertTemperaturas } = require('../db/clickhouse');

// POST /metric
router.post('/metric', async (req, res) => {
  const { maquina, valor } = req.body;
  const valorFloat = parseFloat(valor);

  try {
    if (!maquina || Number.isNaN(valorFloat)) {
      return res.status(400).json({ erro: 'Informe maquina e valor numérico' });
    }

    await influx.writePoints([
      {
        measurement: 'leituras',
        tags: { maquina },
        fields: { valor: valorFloat },
      }
    ]);

    await insertTemperaturas([
      {
        timestamp: new Date().toISOString().replace('T', ' ').replace('Z', ''),
        maquina,
        valor: valorFloat,
      },
    ]);
    console.log(`[metric] OK maquina=${maquina} valor=${valorFloat}`);

    res.json({ mensagem: 'Leitura registrada com sucesso!' });
  } catch (e) {
    console.error('[metric] erro ao inserir', e.message);
    res.status(500).json({ erro: e.message });
  }
});

// GET /metric/latest
router.get('/metric/latest', async (req, res) => {
  try {
    const result = await influx.query(`
      select * from leituras order by time desc limit 20
    `);

    res.json(result);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

module.exports = router;
