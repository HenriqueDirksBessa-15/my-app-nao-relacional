const express = require('express');
const router = express.Router();
const { clickhouse, insertTemperaturas } = require('../db/clickhouse');
const influx = require('../db/influx');

async function syncUltimos10() {
  // Busca as 10 últimas leituras no Influx e insere no ClickHouse
  const result = await influx.query(`
    SELECT maquina, valor, time
    FROM leituras
    ORDER BY time DESC
    LIMIT 10
  `);

  if (!result.length) return;

  const payload = result.map(r => ({
    timestamp: new Date(r.time).toISOString().replace('T', ' ').replace('Z', ''),
    maquina: r.maquina,
    valor: parseFloat(r.valor),
  }));

  await insertTemperaturas(payload);
}

// GET /stats/diario
router.get('/diario', async (req, res) => {
  try {
    await syncUltimos10();

    const rows = await clickhouse.query(`
      SELECT 
        maquina,
        AVG(valor) as media,
        toDate(timestamp) AS dia
      FROM temperaturas_diarias
      GROUP BY maquina, dia
      ORDER BY dia DESC
      LIMIT 7
    `).toPromise();

    res.json(rows.data);
  } catch (e) {
    console.error('[stats/diario] erro:', e.message);
    res.status(500).json({ erro: e.message });
  }
});

// GET /stats/raw - últimas leituras já armazenadas no ClickHouse
router.get('/raw', async (_req, res) => {
  try {
    const rows = await clickhouse
      .query(`
        SELECT timestamp, maquina, valor
        FROM temperaturas_diarias
        ORDER BY timestamp DESC
        LIMIT 10
      `)
      .toPromise();

    res.json(rows.data);
  } catch (e) {
    console.error('[stats/raw] erro:', e.message);
    res.status(500).json({ erro: e.message });
  }
});

module.exports = router;
