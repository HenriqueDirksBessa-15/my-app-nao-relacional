const app = require('./app');

app.listen(3001, () => {
  console.log("Backend rodando na porta 3001");
});
