import { useEffect, useState } from "react";
import { api } from "./api";

export default function App() {
  const [maquina, setMaquina] = useState("A1");
  const [valor, setValor] = useState("");
  const [leituras, setLeituras] = useState([]);
  const [stats, setStats] = useState([]);
  const [leiturasCH, setLeiturasCH] = useState([]);

  const enviarLeitura = async () => {
    try {
      await api.post("/metrics/metric", { maquina, valor });
    } catch (err) {
      console.error("Erro ao enviar leitura:", err);
      return;
    }
    carregarLeituras();
    carregarStats();
    carregarLeiturasCH();
  };

  const carregarLeituras = async () => {
    try {
      const res = await api.get("/metrics/metric/latest");
      setLeituras(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      console.error("Erro ao carregar leituras:", err);
      setLeituras([]);
    }
  };

  const carregarStats = async () => {
    try {
      const res = await api.get("/stats/diario");
      setStats(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      console.error("Erro ao carregar stats:", err);
      setStats([]);
    }
  };

  const carregarLeiturasCH = async () => {
    try {
      const res = await api.get("/stats/raw");
      setLeiturasCH(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      console.error("Erro ao carregar leituras do ClickHouse:", err);
      setLeiturasCH([]);
    }
  };

  useEffect(() => {
    carregarLeituras();
    carregarStats();
    carregarLeiturasCH();
  }, []);

  return (
    <div style={{ padding: 20, fontFamily: "Arial", maxWidth: 960, margin: "0 auto" }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h2 style={{ margin: 0 }}>Monitoramento</h2>
        <nav style={{ display: "flex", gap: 12 }}>
          <a href="#nova">Nova Leitura</a>
          <a href="#ultimas">Últimas Leituras</a>
          <a href="#diario">Relatório Diário</a>
        </nav>
      </header>
      <h3 style={{ marginTop: 0 }}>InfluxDB + ClickHouse</h3>

      <div id="nova">
        <h3>Nova Leitura</h3>
        <input value={maquina} onChange={e => setMaquina(e.target.value)} />
        <input value={valor} onChange={e => setValor(e.target.value)} type="number" />
        <button onClick={enviarLeitura}>Enviar</button>
      </div>

      <hr />

      <h3 id="ultimas">Últimas Leituras (InfluxDB)</h3>
      <ul>
        {leituras.map((l, i) => (
          <li key={i}>Máquina {l.maquina}: {l.valor}°C</li>
        ))}
      </ul>

      <hr />

      <h3 id="diario">Estatísticas Diárias (ClickHouse)</h3>
      <ul>
        {stats.map((s, i) => (
          <li key={i}>
            {s.maquina} - Média: {Number(s.media).toFixed(2)}°C em {s.dia}
          </li>
        ))}
      </ul>

      <hr />

      <h3>Últimas Leituras Gravadas no ClickHouse</h3>
      <ul>
        {leiturasCH.map((l, i) => (
          <li key={i}>
            {l.timestamp} — {l.maquina}: {l.valor}°C
          </li>
        ))}
      </ul>
    </div>
  );
}
